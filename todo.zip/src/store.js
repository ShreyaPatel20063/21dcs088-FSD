import { configureStore } from "@reduxjs/toolkit";
import taskReducer from "./redux/taskReducer";

const store = configureStore({
  reducer: {
    tasklist: taskReducer, // Make sure 'tasklist' matches your reducer name
  },
});

export default store;
