import React from "react";
import TaskCard from "./TaskCard";
import { useSelector, useDispatch } from "react-redux";
const Home = () => {
  // Default Task
  const taskListData = useSelector((state) => state.tasklist);
  return (
    <>
      {taskListData.map((task) => (
        <TaskCard title={task.title} desc={task.desc} />
      ))}
      {/* {taskListData.map((task) => (
        <li key={task.title}>
          <strong>{task.title}:</strong> {task.desc}
        </li>
      ))} */}
    </>
  );
};

export default Home;
