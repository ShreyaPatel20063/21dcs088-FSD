import { createSlice } from "@reduxjs/toolkit";

const initialState = [
  {
    title: "Uttar Pradesh",
    desc: "Lucknow",
  },
  {
    title: "Gujarat",
    desc: "Gandhinagar",
  },
  {
    title: "Karnataka",
    desc: "Bengaluru",
  },
  {
    title: "Punjab",
    desc: "Chandigarh",
  },
  {
    title: "Maharashtra",
    desc: "Mumbai",
  },
];

export const taskSlice = createSlice({
  name: "tasklist",
  initialState,
  reducers: {
    addTask: (state, action) => {
      state.push(action.payload); // Add a new task to the array
      console.log("Hello");
    },
    deleteTask: (state, action) => {
      const taskIndex = state.findIndex(
        (task) => task.title === action.payload
      );
      if (taskIndex !== -1) {
        state.splice(taskIndex, 1); // Delete a task by its title
      }
    },
    updateTask: (state, action) => {
      const { title, desc } = action.payload;
      const taskIndex = state.findIndex((task) => task.title === title);
      if (taskIndex !== -1) {
        state[taskIndex].desc = desc; // Update a task's description by its title
      }
    },
  },
});

export const { addTask, deleteTask, updateTask } = taskSlice.actions;

export default taskSlice.reducer;
