import React from 'react'

export default function About() {
  return (
    <>
      <h1 style={{textAlign:"center"}}>About-Us</h1>
    </>
  )
}
