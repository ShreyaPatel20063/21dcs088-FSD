import React from 'react'
import Loginsignup from '../Loginsignin'

export default function Home() {
  return (
    <>
      <Loginsignup/>
    </>
  )
}
